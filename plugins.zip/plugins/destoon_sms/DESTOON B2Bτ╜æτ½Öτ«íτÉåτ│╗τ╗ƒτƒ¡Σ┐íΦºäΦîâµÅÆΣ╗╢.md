## OVERVIEW

### DESTOON B2B网站管理系统 Plug-Ins Overview

>DESTOON B2B网站系统是基于PHP+MySQL的开源B2B(电子商务)行业门户的首选解决方案.

------
DESTOON     [官网地址](https://www.destoon.com)
	
How to use
-	admin/template/setting.tpl.php
-	admin/setting.inc.php
-	include/global.func.php

	1.将插件内的文件覆盖至你的网站系统根目录
	2.进入系统工具->云服务->短信设置，填写赛邮云短信相关的账号密码


![Submail](./markdown/1.png)

[Github项目地址](https://github.com/submail-developers/destoon_sms)&nbsp;&nbsp;&nbsp;[点击下载](https://github.com/submail-developers/destoon_sms/archive/master.zip)
