<?php
return [
    'sms_account'=>[
        'title'=>'用户账号',
        'value'=>'',
    ],
    'sms_password'=>[
        'title'=>'用户密码',
        'value'=>'',
    ],
    'sms_prefix'=>[
        'title'=>'短信签名',
        'value'=>'jshop',
    ]
];
