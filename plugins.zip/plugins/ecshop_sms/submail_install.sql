INSERT INTO `ecs_shop_config` VALUES ('90', '0', '赛邮云设置', 'group', '', '', '', '1');
INSERT INTO `ecs_shop_config` VALUES ('', '90', '赛邮云账号', 'text', '', '', '', '1');
INSERT INTO `ecs_shop_config` VALUES ('', '90', '赛邮云密码', 'password', '', '', '', '1');