## OVERVIEW

### Ecshop Plug-Ins Overview

>ECShop是一款专业的电商商城系统, 跨平台开源程序,源码支持免费下载!ECShop可以快速构建PC+微商城+APP+小程序等多终端商城，并支持二次开发定制化商城。

------
Ecshop  [官网地址](https://www.ecshop.com)

How to use
-	includes/cls_sms.php
-
使用方法

    把下载好的Ecshop赛邮云插件程序解压覆盖到网站根目录
    浏览器地址栏输入：http://域名/submail_install.php，成功后请将ECShop根目录下的submail_install.php文件删除

登录后台管理界面

    进入系统后台->系统设置->商店设置，填写赛邮云短信账号信息，保存
    在商店设置—>短信设置，填写商家的手机号，编辑短信开关
    短信管理->短信签名处添加短信签名，并设置一个默认签名。
    Linux环境请设置插件文件的读写权限（777）


[Github项目地址](https://github.com/submail-developers/ecshop_sms)&nbsp;&nbsp;&nbsp;[点击下载](https://github.com/submail-developers/ecshop_sms/archive/master.zip)
