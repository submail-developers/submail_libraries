## OVERVIEW

### UQCMS Plug-Ins Overview

>电商网站的开发与建设。B2B2C网站开发，B2B2C源码建站，网站一条龙服务。

------

UQCMS  [官网地址](http://www.uqcms.com/)

How to use
-	admin/controls/submail.class.php
-	UQframework/api/sms_submail.class.php

使用方法
    添加submail sql:    /admin/controls/submail.class.php
    添加Submail sms-sdk:    /UQframework/api/sms_submail.class.php
登录后台管理界面

![Submail](./markdown/1.png)
![Submail](./markdown/2.png)
![Submail](./markdown/3.png)
![Submail](./markdown/4.png)


[Github项目地址](https://github.com/submail-developers/uqcms_sms/)&nbsp;&nbsp;&nbsp;[点击下载](https://github.com/submail-developers/uqcms_sms/archive/master.zip)
