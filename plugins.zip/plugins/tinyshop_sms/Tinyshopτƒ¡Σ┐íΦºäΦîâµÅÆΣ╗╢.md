## OVERVIEW

### Tinyshop Plug-Ins Overview

>TinyShop网店系统，国内商城系统及服务提供领先品牌。为传统企业及创业者提供零售网店及解决方案。

------

Tinyshop  [官网地址](http://tinyrise.com/)

How to use

-	protected/classes/Menu.php
-	protected/classes/Sms.php
-	protected/controllers/ucenter.php
-	protected/services/config.php
-	protected/views/admin/config_sms.html

使用方法
        1：本插件针对TinyShop系统3.1开发，安装前请仔细核对你的系统软件版本；
        2：如果你的软件经过二次开发，请核对修改，谨慎覆盖；。
        3：进入系统后台->参数设定->短信配置，填写赛邮云短信配置，为保证短信发送正常。


![Submail](./markdown/1.png)

[Github项目地址](https://github.com/submail-developers/tinyshop_sms)&nbsp;&nbsp;&nbsp;[点击下载](https://github.com/submail-developers/tinyshop_sms/archive/master.zip)
