## OVERVIEW

### HADSKY Plug-Ins Overview

>HadSky轻论坛是一款新生原创的PHP+MySQL开源系统，主要目标是实现轻、快、简、全，100%的原创开源系统。

------
HADSKY [官网地址](https://www.hadsky.com)

How to use
-	app/hadskycloudserver/phpscript/sms_send.php
-	app/hadskycloudserver/setting.hst

使用方法
    把下载好的HADSKY 赛邮云短信插件程序解压覆盖到网站根目录

![Submail](./markdown/1.png)

[Github项目地址](https://github.com/submail-developers/hadsky_sms)&nbsp;&nbsp;&nbsp;[点击下载](https://github.com/submail-developers/hadsky_sms/archive/master.zip)
