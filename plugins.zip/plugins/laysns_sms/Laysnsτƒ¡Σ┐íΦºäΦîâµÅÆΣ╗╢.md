## OVERVIEW

### Laysns_SMS Plug-Ins Overview

>LaySNS是一款轻量级，基于ThinkPHP+Layui架构的集内容管理与社区互动为一体的综合建站系统。

------
Laysns  [官网地址](https://bbs.laysns.com/)

How to use

-	application/admin/view/system_sms.html
-	application/index/controller/Api.php

使用方法
    1:首先将Laysns正确安装<br>
    2:将本目录下三个文件夹上传至网站根目录，覆盖原有文件 <br>
    3:运行submail_install.php文件:http://你的网址/submail_install.php,  出现job done说明数据插 入成功 <br>
    4:进入后台，刷新缓存，选择系统配置->站点配置->服务设置->短信平台设置，选择，<br>
![Submail](./markdown/1.png)

5:安装完成后将submail_install.php删除
6:测试手机注册 短信发送

![Submail](./markdown/2.png)


[Github项目地址](https://github.com/submail-developers/laysns_sms)&nbsp;&nbsp;&nbsp;[点击下载](https://github.com/submail-developers/laysns_sms/archive/master.zip)
