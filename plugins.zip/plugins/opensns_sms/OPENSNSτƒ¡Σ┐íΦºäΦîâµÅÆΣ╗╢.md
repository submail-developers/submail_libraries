
## OVERVIEW

### OPENSNS Plug-Ins Overview

>OpenSNS开源社交建站系统，包含微博、资讯、论坛、群组、问答、微店等模块，可适应行业多元化，领先级SNS社交app软件开发公司。

------

OPENSNS  [官网地址](http://www.opensns.cn/)

How to use
-	Addons/Submail/config.php
-	Addons/Submail/SubmailAddon.class.php

        1：本插件针对OPENSNS开发，安装前请仔细核对你的系统版本。
        2：请直接将插件内的文件覆盖原文件。
        3：登录后台参照如下图所示位置更改配置。

![Submail](./markdown/1.png)



![Submail](./markdown/2.png)

![Submail](./markdown/3.png)

![Submail](./markdown/4.png)


[Github项目地址](https://github.com/submail-developers/opensns_sms)&nbsp;&nbsp;&nbsp;[点击下载](https://github.com/submail-developers/opensns_sms/archive/master.zip)

