## OVERVIEW

### EduSoho Plug-Ins Overview

>EduSoho开源网络课堂是杭州阔知网络科技开发的在线学习直播网校系统。

------

EduSoho [官网地址](http://www.edusoho.com)

How to use
-	app/Resources/views/admin/system/auth.html.twig
-	src/AppBundle/Controller/Admin/UserSettingController.php
-	src/AppBundle/Controller/EduCloudController.php

使用方法

进入系统后台->系统-》用户设置-》注册-》用户注册模式，选择手机注册，填写Submail配置相关信息并保存。

[Github项目地址](https://github.com/submail-developers/edusoho_sms)&nbsp;&nbsp;&nbsp;[点击下载](https://github.com/submail-developers/edusoho_sms/archive/master.zip)
