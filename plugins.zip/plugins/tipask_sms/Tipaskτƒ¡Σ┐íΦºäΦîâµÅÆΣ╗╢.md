## OVERVIEW

### Tipask Plug-Ins Overview

>Tipask旨在为大家提供开源、稳定、功能强大的、值得使用的问答系统。

Tipask  [官网地址](https://www.tipask.com/)

------
-	app/Services/SmsService.php
-	config/submailsms.php
-	resources/views/admin/setting/sms.blade.php


How to use

使用方法
    1:首先将Tipask正确安装
    2:将本目录下三个文件夹上传至网站对应目录
    3:进入后台，填入Appid 和Signature，签名 以及模板ID（project）

![Submail](./markdown/1.png)

[Github项目地址](https://github.com/submail-developers/tipask_sms)&nbsp;&nbsp;&nbsp;[点击下载](https://github.com/submail-developers/tipask_sms/archive/master.zip)

