## OVERVIEW

### SHOPXO使用规范 Plug-Ins Overview

>ShopXO企业级B2C免费开源电商系统，为企业提供php商城系统、微信商城、小程序。

------

SHOPXO  [官网地址](https://shopxo.net/)

How to use

-	application/admin/view/default/sms/index.html
-	application/admin/view/default/sms/nav.html
-	extend/base/Sms.php

使用方法
    把下载好的SHOPXO 赛邮云短信插件程序解压覆盖到网站根目录

![Submail](./markdown/1.png)
![Submail](./markdown/2.png)


然后就完成了短信配置


[Github项目地址](https://github.com/submail-developers/shopxo_sms)&nbsp;&nbsp;&nbsp;[点击下载](https://github.com/submail-developers/shopxo_sms/archive/master.zip)
