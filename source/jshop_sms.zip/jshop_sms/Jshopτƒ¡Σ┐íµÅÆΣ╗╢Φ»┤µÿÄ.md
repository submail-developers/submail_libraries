## OVERVIEW

### Jshop Plug-Ins Overview

------
	Jshop 短信插件
How to use

使用方法
    把下载好的Jshop商城 赛邮云短信插件程序解压覆盖到网站根目录     
    找到 控制面板->插件列表

    
![Submail](./markdown/1.png)

    点击安装 后
    
    配置好申请的appid 和 appkey

![Submail](./markdown/2.png)

