<?php


return [
    'access_key'        => env('SMS_KEY_ID',''), // accessKey
    'access_secret'     => env('SMS_KEY_SECRET',''), // accessSecret
    'sign_name'         => env('SMS_SIGN_NAME',''), // 签名
];
