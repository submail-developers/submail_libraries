## OVERVIEW

### Tipask Plug-Ins Overview

------

How to use

使用方法
    1:首先将天天团购正确安装
    2:将本目录下三个文件夹上传至网站对应目录
    3:进入后台，填入appid 和Signature，签名 以及模板ID（project）

![Submail](./markdown/1.png)