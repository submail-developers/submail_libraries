## OVERVIEW

### EduSoho Plug-Ins Overview

------

How to use

使用方法
    替换文件路径分别为：
    app/Resources/views/admin/system/auth.html.twig
    src/AppBundle/Controller/Admin/UserSettingController.php
    src/AppBundle/Controller/EduCloudController.php

进入系统后台->系统-》用户设置-》注册-》用户注册模式，选择手机注册，填写Submail配置相关信息并保存。


